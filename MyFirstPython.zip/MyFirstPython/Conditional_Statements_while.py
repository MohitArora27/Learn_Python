#Explicit conversion to 0


c=10
while c!=0:
    print(2*c)
    c-=1

#print("Explicit Conversion")
#implicit conversion to 0
#d=10
#while d:
 #   print(2*d)
  #  c-=1


#Recommended is explicit conversion