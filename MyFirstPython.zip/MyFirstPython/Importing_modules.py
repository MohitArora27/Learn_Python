import math
m=4
n=math.sqrt(m)
x=5
y=6
z=x+y
print(n+z)
