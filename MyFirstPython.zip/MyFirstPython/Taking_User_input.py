c=5
response=input()
while c!=0:
    print(int(response)*c)
    c-=1