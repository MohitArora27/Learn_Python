g=21
if g==20:
    print("Hello World")
else:
    print("Hello False")
