print(2+4)
c=4
d=6
e=c+d
print(e)